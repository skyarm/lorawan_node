/**
 ******************************************************************************
 *
 *          Portions COPYRIGHT 2020 STMicroelectronics
 *
 * @file    LmHandler.c
 * @author  MCD Application Team
 * @brief   LoRaMAC Layer handling definition
 ******************************************************************************
 */
#include <zephyr/kernel.h>
#include <zephyr/init.h>
#include <errno.h>
#include <string.h>
#include <assert.h>
#include <time.h>
#include <zephyr/lorawan/lorawan_node.h>

#include <LoRaMac.h>
#include <Region.h>
#include <LoRaMacClassB.h>
#include <LoRaMacTest.h>

#include <zephyr/logging/log.h>
LOG_MODULE_REGISTER(lorawan_node, CONFIG_LORAWAN_NODE_LOG_LEVEL);

static const struct lorawan_node_config *lorawan_node_config = NULL;

struct lorawan_node_runtime {
	bool duty_cycle_enabled;  /* ths parameter defined in region files */
	uint32_t duty_cycle_time; /* the next duty cycle time */
	uint32_t device_address;
	uint8_t device_eui[8];
	uint8_t join_eui[8];
	enum lorawan_node_region actived_region;
	bool ctx_restore_done;
#ifdef CONFIG_LORAWAN_NODE_CLASSB
	/*Indicates if a switch to Class B operation is pending or not. */
	bool classb_pending;
#endif /* CONFIG_LORAWAN_NODE_CLASSB */
};

static struct lorawan_node_runtime lorawan_node_runtime = {
	.duty_cycle_enabled = false, /* will be set in lorawan_node_init as region settings */
	.duty_cycle_time = UINT32_MAX,
	.device_address = 0,
	.device_eui = {0},
	.join_eui = {0},
	.actived_region = -1,
	.ctx_restore_done = false,
#if CONFIG_LORAWAN_NODE_CLASSB == 1
	.classb_pending = false,
#endif /* CONFIG_LORAWAN_NODE_CLASSB == 1 */
};

struct lorawan_node_mac_config {
	/* Used to notify node of LoRaMac events */
	LoRaMacPrimitives_t primitives;
	/* LoRaMac callbacks */
	LoRaMacCallback_t callbacks;
};

static struct lorawan_node_mac_config lorawan_node_mac_config = {0};

#ifdef CONFIG_LORAWAN_NODE_CLASSB
static enum lorawan_node_status lorawan_node_beacon_req(void)
{
	MlmeReq_t mlme_req;

	mlme_req.Type = MLME_BEACON_ACQUISITION;
	return (enum lorawan_node_status)LoRaMacMlmeRequest(&mlme_req);
}

static enum lorawan_node_status lorawan_node_ping_slot_req()
{
	LoRaMacStatus_t status;
	MlmeReq_t mlme_req;

	mlme_req.Type = MLME_PING_SLOT_INFO;
#ifdef CONFIG_LORAWAN_NODE_PING_SLOT_PERIODCITY
	mlme_req.Req.PingSlotInfo.PingSlot.Fields.Periodicity = CONFIG_LORAWAN_NODE_PING_PERIODCITY;
#else
	mlme_req.Req.PingSlotInfo.PingSlot.Fields.Periodicity = 7;
#endif

#ifdef CONFIG_LORAWAN_NODE_PING_SLOT_DR
	mlme_req.Req.PingSlotInfo.PingSlot.Fields.RFU = CONFIG_LORAWAN_NODE_PING_DR;
#else
	mlme_req.Req.PingSlotInfo.PingSlot.Fields.RFU = LORAWAN_NODE_DR_2;
#endif
	// FIXME: What is the BIT[5], 0b1 or 0b0?
	mlme_req.Req.PingSlotInfo.PingSlot.Fields.RFU |= 0x10;

	status = LoRaMacMlmeRequest(&mlme_req);
	if (status == LORAMAC_STATUS_OK) {
		return lorawan_node_send(0, NULL, 0, false);
	} else {
		return (enum lorawan_node_status)status;
	}
}
#endif /* CONFIG_LORAWAN_NODE_CLASSB */

static void lorawan_node_mcps_confirm(McpsConfirm_t *mcps_confirm)
{
	struct lorawan_node_cb_send_params cb_params;

	cb_params.is_mcps_confirm = true;
	cb_params.status = (enum lorawan_node_event_status)mcps_confirm->Status;
	cb_params.data_rate = mcps_confirm->Datarate;
	cb_params.uplink_counter = mcps_confirm->UpLinkCounter;
	cb_params.tx_power = mcps_confirm->TxPower;
	cb_params.channel = mcps_confirm->Channel;
	cb_params.ack_received = mcps_confirm->AckReceived;

	if (lorawan_node_config->callbacks.send) {
		lorawan_node_config->callbacks.send(&cb_params);
	}
}

static void lorawan_node_mcps_indication(McpsIndication_t *mcps_indication, LoRaMacRxStatus_t *rx_status)
{
	DeviceClass_t device_class;
	struct lorawan_node_cb_recv_params cb_params;

	cb_params.is_mcps_indication = true;
	cb_params.status = (enum lorawan_node_event_status)mcps_indication->Status;

	if (cb_params.status != LORAWAN_NODE_EVENT_STATUS_OK) {
		return;
	}

	if (mcps_indication->BufferSize > 0) {
		cb_params.data_rate = mcps_indication->RxDatarate;
		cb_params.rssi = rx_status->Rssi;
		cb_params.snr = rx_status->Snr;
		cb_params.rx_slot = rx_status->RxSlot;
		cb_params.downlink_counter = mcps_indication->DownLinkCounter;

		if (lorawan_node_config->callbacks.recv) {
			lorawan_node_config->callbacks.recv(
				mcps_indication->Port, mcps_indication->Buffer,
				mcps_indication->BufferSize, &cb_params);
		}
	}

	device_class = lorawan_node_get_current_class();
	if ((mcps_indication->IsUplinkTxPending) && (device_class == CLASS_A)) {
		/**
		 * *The server signals that it has pending data to be sent.
		 * We schedule an uplink as soon as possible to flush the server.
		 * Send an empty message
		 */
		enum lorawan_node_status status = lorawan_node_send(0, NULL, 0, false);
		if (status != LORAWAN_NODE_STATUS_OK) {
			LOG_WRN("Schedule an uplink failed with status: %d", status);
		}
	}
}

static void lorawan_node_mlme_confirm(MlmeConfirm_t *mlme_confirm)
{
	switch (mlme_confirm->MlmeRequest) {
	case MLME_JOIN: {
		struct lorawan_node_cb_join_params cb_params;
		cb_params.mode = LORAWAN_NODE_ACTIVATION_OTAA;

		MibRequestConfirm_t mib_req;
		mib_req.Type = MIB_DEV_ADDR;
		LoRaMacMibGetRequestConfirm(&mib_req);
		lorawan_node_runtime.device_address = mib_req.Param.DevAddr;

		cb_params.status = (enum lorawan_node_event_status)mlme_confirm->Status;
		/* Notify upper layer */
		if (lorawan_node_config->callbacks.join) {
			lorawan_node_config->callbacks.join(&cb_params);
		}
	} break;
	case MLME_LINK_CHECK: {
		/* Check DemodMargin */
		/* Check NbGateways */
		LOG_INF("Link check not implemented yet!");
	} break;
	case MLME_DEVICE_TIME: {
#if CONFIG_LORAWAN_NODE_CLASSB == 1
		if (mlme_confirm->Status == LORAMAC_EVENT_INFO_STATUS_OK) {
			SysTime_t systime = SysTimeGet();
			struct tm *tm;
			time_t secs = (time_t)systime.Seconds;
			tm = gmtime(&secs);
			LOG_DBG("Got Device Time[%d:%d:%d.%u].", (tm->tm_hour + 8) % 24,
				tm->tm_min, (tm->tm_sec - 19) % 60, systime.SubSeconds);
			if (lorawan_node_runtime.classb_pending == true) {
				LOG_DBG("Start Beacon Acquisition...");
				enum lorawan_node_status status = lorawan_node_beacon_req();
				if (status != LORAWAN_NODE_STATUS_OK) {
					LOG_WRN("Beacon Acquisition failed with status: %d",
						status);
				}
			}
		} else {
			LOG_DBG("Delivered Device Time failed with status: %d",
				mlme_confirm->Status);
			LOG_DBG("Try to request Device Time again...");
			enum lorawan_node_status status = lorawan_node_device_time_req();
			if (status != LORAWAN_NODE_STATUS_OK) {
				LOG_WRN("Request Device Time failed with status: %d", status);
			}
		}
#endif /* CONFIG_LORAWAN_NODE_CLASSB */
	} break;
#if CONFIG_LORAWAN_NODE_CLASSB == 1
	case MLME_BEACON_ACQUISITION: {
		if (mlme_confirm->Status == LORAMAC_EVENT_INFO_STATUS_OK) {
			/* Request server for ping slot */
			enum lorawan_node_status status = lorawan_node_ping_slot_req();
			if (status != LORAWAN_NODE_STATUS_OK) {
				LOG_WRN("Ping slot Request failed with status: %d", status);
			}
		} else {
			LOG_DBG("Beacon Acquisition failed with status: %d.", mlme_confirm->Status);
			enum lorawan_node_status status = lorawan_node_device_time_req();
			if (status != LORAWAN_NODE_STATUS_OK) {
				LOG_WRN("Request Beacon Acquisition with status: %d", status);
			}
		}
	} break;
	case MLME_PING_SLOT_INFO: {
		if (mlme_confirm->Status == LORAMAC_EVENT_INFO_STATUS_OK) {
			LoRaMacStatus_t status;
			MibRequestConfirm_t mib_req;
			/* Class B is now activated */
			mib_req.Type = MIB_DEVICE_CLASS;
			mib_req.Param.Class = CLASS_B;
			status = LoRaMacMibSetRequestConfirm(&mib_req);
			if (status != LORAMAC_STATUS_OK) {
				LOG_WRN("Switch to class B failed with status: %d", status);
			} else {
				enum lorawan_node_status status;
				/* Tell the network server, class has been changed */
				status = lorawan_node_send(0, NULL, 0, false);
				if (status != LORAWAN_NODE_STATUS_OK) {
					LOG_WRN("Submit Change class to B failed with status: %d",
						status);
				}
			}
			if (lorawan_node_config->callbacks.class_changed) {
				lorawan_node_config->callbacks.class_changed(CLASS_B);
			}
			lorawan_node_runtime.classb_pending = false;
		} else {
			LOG_DBG("Delivered Ping Slot Info Response with status: %d",
				mlme_confirm->Status);
			enum lorawan_node_status status = lorawan_node_ping_slot_req();
			if (status != LORAWAN_NODE_STATUS_OK) {
				LOG_WRN("Submit Ping Slot Request failed with status: %d", status);
			}
		}
	} break;
#endif /* CONFIG_LORAWAN_NODE_CLASSB */
	default:
		break;
	}
}

static void lorawan_node_mlme_indication(MlmeIndication_t *mlme_indication, LoRaMacRxStatus_t* RxStatus)
{
	struct lorawan_node_cb_beacon_status_params cb_params;

	switch (mlme_indication->MlmeIndication) {
#if CONFIG_LORAWAN_NODE_CLASSB == 1
	case MLME_BEACON_LOST: {
		MibRequestConfirm_t mib_req;
		/* Switch to class A again */
		mib_req.Type = MIB_DEVICE_CLASS;
		mib_req.Param.Class = CLASS_A;
		LoRaMacMibSetRequestConfirm(&mib_req);

		cb_params.status = LORAWAN_NODE_EVENT_STATUS_BEACON_LOST;
		cb_params.seconds = 0;
		cb_params.subseconds = 0;
		cb_params.info_desc = 0;
		memset(cb_params.info_data, 0, 6);
		if (lorawan_node_config->callbacks.beacon_status) {
			lorawan_node_config->callbacks.beacon_status(&cb_params);
		}
		if (lorawan_node_config->callbacks.class_changed) {
			lorawan_node_config->callbacks.class_changed(CLASS_A);
		}

		enum lorawan_node_status status = lorawan_node_device_time_req();
		if (status != LORAWAN_NODE_STATUS_OK) {
			LOG_WRN("Request Device Time failed with status: %d", status);
		}
	} break;
	case MLME_BEACON: {
		cb_params.status = (enum lorawan_node_event_status)mlme_indication->Status;
		cb_params.seconds = mlme_indication->BeaconInfo.Time.Seconds;
		cb_params.subseconds = mlme_indication->BeaconInfo.Time.SubSeconds;
		cb_params.freq = mlme_indication->BeaconInfo.Frequency;
		cb_params.rssi = mlme_indication->BeaconInfo.Rssi;
		cb_params.snr = mlme_indication->BeaconInfo.Snr;
		cb_params.info_desc = mlme_indication->BeaconInfo.GwSpecific.InfoDesc;
		memcpy(cb_params.info_data, mlme_indication->BeaconInfo.GwSpecific.Info,
		       sizeof(cb_params.info_data));
		if (lorawan_node_config->callbacks.beacon_status) {
			lorawan_node_config->callbacks.beacon_status(&cb_params);
		}
		break;
	}
#endif /* CONFIG_LORAWAN_NODE_CLASSB */
	default:
		break;
	}
}

static void lorawan_node_nvm_data_change(uint16_t notifyFlags)
{
}

static bool lorawan_node_nvm_ctx_store(void)
{
	return false;
}

static bool lorawan_node_nvm_ctx_restore(void)
{
	return false;
}

enum lorawan_node_status lorawan_node_init(const struct lorawan_node_config *config)
{
	if (lorawan_node_config) {
		/**
		 * The lorawan node is already initialed
		 * But when the device reset and the SRAM keep the data,
		 * Can calc a checksum of config data and need not initial
		 * the device again?
		 */
		assert(0);
		return LORAWAN_NODE_STATUS_ERROR;
	}

	/**
	 * initial lora_node_mac_config
	 */
	lorawan_node_mac_config.primitives.MacMcpsConfirm = lorawan_node_mcps_confirm;
	lorawan_node_mac_config.primitives.MacMcpsIndication = lorawan_node_mcps_indication;
	lorawan_node_mac_config.primitives.MacMlmeConfirm = lorawan_node_mlme_confirm;
	lorawan_node_mac_config.primitives.MacMlmeIndication = lorawan_node_mlme_indication;
	lorawan_node_mac_config.callbacks.NvmDataChange = lorawan_node_nvm_data_change;
	lorawan_node_mac_config.callbacks.GetBatteryLevel = config->callbacks.battery_level;
	lorawan_node_mac_config.callbacks.GetTemperatureLevel = config->callbacks.temperature;
	lorawan_node_mac_config.callbacks.MacProcessNotify = config->callbacks.process;

	/**
	 * Initial runtime data
	 */
	lorawan_node_runtime.device_address = 0;
	lorawan_node_runtime.duty_cycle_time = k_uptime_get_32();

#if CONFIG_LORAWAN_NODE_CLASSB == 1
	lorawan_node_runtime.classb_pending = false;
#endif /* CONFIG_LORAWAN_NODE_CLASSB */
	lorawan_node_runtime.ctx_restore_done = false;

#if CONFIG_LORAWAN_NODE_REGION_AS923 == 1
	lorawan_node_runtime.actived_region = LORAMAC_REGION_AS923;
#endif /* REGION_AS923 */
#if CONFIG_LORAWAN_NODE_REGION_AU915 == 1
	lorawan_node_runtime.actived_region = LORAMAC_REGION_AU915;
#endif /* REGION_AU915 */
#if CONFIG_LORAWAN_NODE_REGION_CN470 == 1
	lorawan_node_runtime.actived_region = LORAMAC_REGION_CN470;
#endif /* REGION_CN470 */
#if CONFIG_LORAWAN_NODE_REGION_CN779 == 1
	lorawan_node_runtime.actived_region = LORAMAC_REGION_CN779;
#endif /* REGION_CN779 */
#if CONFIG_LORAWAN_NODE_REGION_EU433 == 1
	lorawan_node_runtime.actived_region = LORAMAC_REGION_EU433;
#endif /* REGION_EU433 */
#if CONFIG_LORAWAN_NODE_REGION_EU868 == 1
	lorawan_node_runtime.actived_region = LORAMAC_REGION_EU868;
#endif /* REGION_EU868 */
#if CONFIG_LORAWAN_NODE_REGION_KR920 == 1
	lorawan_node_runtime.actived_region = LORAMAC_REGION_KR920;
#endif /* REGION_KR920 */
#if CONFIG_LORAWAN_NODE_REGION_IN865 == 1
	lorawan_node_runtime.actived_region = LORAMAC_REGION_IN865;
#endif /* REGION_IN865 */
#if CONFIG_LORAWAN_NODE_REGION_US915 == 1
	lorawan_node_runtime.actived_region = LORAMAC_REGION_US915;
#endif /* REGION_US915 */
#if CONFIG_LORAWAN_NODE_REGION_RU864 == 1
	lorawan_node_runtime.actived_region = LORAMAC_REGION_RU864;
#endif /* REGION_RU864 */

	if ((int)lorawan_node_runtime.actived_region == -1) {
		assert(0); /* At least one region shall be defined */
		return LORAWAN_NODE_STATUS_ERROR;
	}

	/**
	 * Initial LoraMac
	 */
	LoRaMacStatus_t status;
	status = LoRaMacInitialization(&lorawan_node_mac_config.primitives,
				       &lorawan_node_mac_config.callbacks,
				       (LoRaMacRegion_t)lorawan_node_runtime.actived_region);
	if (status != LORAMAC_STATUS_OK) {
		return (enum lorawan_node_status)status;
	}

	/* Try to restore from NVM and query the mac if possible. */
	MibRequestConfirm_t mib_req;
	if (lorawan_node_nvm_ctx_restore()) {
		lorawan_node_runtime.ctx_restore_done = true;
	} else {
		lorawan_node_runtime.ctx_restore_done = false;
		/* Read secure-element DEV_EUI and JOIN_EUI values. */
		mib_req.Type = MIB_DEV_EUI;
		status = LoRaMacMibGetRequestConfirm(&mib_req);
		assert(status == LORAMAC_STATUS_OK);
		memcpy(lorawan_node_runtime.device_eui, mib_req.Param.DevEui, 8);

		mib_req.Type = MIB_JOIN_EUI;
		status = LoRaMacMibGetRequestConfirm(&mib_req);
		assert(status == LORAMAC_STATUS_OK);
		memcpy(lorawan_node_runtime.join_eui, mib_req.Param.JoinEui, 8);
	}

	mib_req.Type = MIB_PUBLIC_NETWORK;
#if CONFIG_LORAWAN_NODE_PUBLIC_NETWORK == 0
	mib_req.Param.EnablePublicNetwork = false;
#else
	mib_req.Param.EnablePublicNetwork = true;
#endif
	status = LoRaMacMibSetRequestConfirm(&mib_req);
	assert(status == LORAMAC_STATUS_OK);

	mib_req.Type = MIB_ADR;
#if CONFIG_LORAWAN_NODE_ADR == 0
	mib_req.Param.AdrEnable = false;
#else
	mib_req.Param.AdrEnable = true;
#endif
	status = LoRaMacMibSetRequestConfirm(&mib_req);
	assert(status == LORAMAC_STATUS_OK);

	mib_req.Type = MIB_SYSTEM_MAX_RX_ERROR;
	mib_req.Param.SystemMaxRxError = CONFIG_LORAWAN_NODE_MAX_RX_ERROR;
	status = LoRaMacMibSetRequestConfirm(&mib_req);
	assert(status == LORAMAC_STATUS_OK);

	GetPhyParams_t get_phy;
	PhyParam_t phy_param;
	get_phy.Attribute = PHY_DUTY_CYCLE;
	phy_param = RegionGetPhyParam(lorawan_node_runtime.actived_region, &get_phy);
	lorawan_node_runtime.duty_cycle_enabled = (bool)phy_param.Value;

	/* override previous value if reconfigure new region */
	LoRaMacTestSetDutyCycleOn(lorawan_node_runtime.duty_cycle_enabled);

	/**
	 * Initial the lorawan_node_config at last of function, thus can
	 * get if the device is initialed when in multithread environment
	 */
	lorawan_node_config = config;

	return LORAWAN_NODE_STATUS_OK;
}

enum lorawan_node_status lorawan_node_join(const struct lorawan_node_join_config *join_cfg)
{
	LoRaMacStatus_t status;
	MibRequestConfirm_t mib_req;

	assert(lorawan_node_config);

	if (join_cfg->mode == LORAWAN_NODE_ACTIVATION_OTAA) {
		MlmeReq_t mlme_req;

		status = LoRaMacStart();
		assert(status == LORAMAC_STATUS_OK);

		mib_req.Type = MIB_DEV_EUI;
		mib_req.Param.DevEui = join_cfg->dev_eui;
		status = LoRaMacMibSetRequestConfirm(&mib_req);
		assert(status == LORAMAC_STATUS_OK);

		mib_req.Type = MIB_JOIN_EUI;
		mib_req.Param.JoinEui = join_cfg->otaa.join_eui;
		status = LoRaMacMibSetRequestConfirm(&mib_req);
		assert(status == LORAMAC_STATUS_OK);

		mib_req.Type = MIB_NWK_KEY;
		mib_req.Param.NwkKey = join_cfg->otaa.nwk_key;
		status = LoRaMacMibSetRequestConfirm(&mib_req);
		assert(status == LORAMAC_STATUS_OK);

		mib_req.Type = MIB_APP_KEY;
		mib_req.Param.AppKey = join_cfg->otaa.app_key;
		status = LoRaMacMibSetRequestConfirm(&mib_req);
		assert(status == LORAMAC_STATUS_OK);

		/* Starts the OTAA join procedure */
		mlme_req.Type = MLME_JOIN;
#ifdef CONFIG_LORAWAN_NODE_DEFAULT_DR
		mlme_req.Req.Join.Datarate = CONFIG_LORAWAN_NODE_DEFAULT_DR;
#else
		mlme_req.Req.Join.Datarate = (uint8_t)LORAWAN_NODE_DR_0;
#endif
		mlme_req.Req.Join.NetworkActivation = ACTIVATION_TYPE_OTAA;
		status = LoRaMacMlmeRequest(&mlme_req);
		assert(status == LORAMAC_STATUS_OK);

		return LORAWAN_NODE_STATUS_OK;

	} else {
		if (lorawan_node_runtime.ctx_restore_done == false) {
			/* Tell the MAC layer which network server version are we connecting too. */
			mib_req.Type = MIB_ABP_LORAWAN_VERSION;
			mib_req.Param.AbpLrWanVersion.Value = LORAWAN_NODE_ABP_VERSION;
			status = LoRaMacMibSetRequestConfirm(&mib_req);
			assert(status == LORAMAC_STATUS_OK);

			mib_req.Type = MIB_NET_ID;
#ifdef CONFIG_LORAWAN_NODE_NETWORK_ID
			mib_req.Param.NetID = CONFIG_LORAWAN_NODE_NETWORK_ID;
#else
			mib_req.Param.NetID = 0;
#endif
			status = LoRaMacMibSetRequestConfirm(&mib_req);
			assert(status == LORAMAC_STATUS_OK);

			mib_req.Type = MIB_DEV_ADDR;
			mib_req.Param.DevAddr = lorawan_node_runtime.device_address;
			status = LoRaMacMibSetRequestConfirm(&mib_req);
			assert(status == LORAMAC_STATUS_OK);
		}

		status = LoRaMacStart();
		if (status != LORAMAC_STATUS_OK) {
			return (enum lorawan_node_status)status;
		}

		mib_req.Type = MIB_NETWORK_ACTIVATION;
		mib_req.Param.NetworkActivation = ACTIVATION_TYPE_ABP;
		status = LoRaMacMibSetRequestConfirm(&mib_req);
		assert(status == LORAMAC_STATUS_OK);

		struct lorawan_node_cb_join_params join_params;
		join_params.mode = ACTIVATION_TYPE_ABP;
		join_params.status = LORAMAC_EVENT_INFO_STATUS_OK;
		if (lorawan_node_config->callbacks.join) {
			(*lorawan_node_config->callbacks.join)(&join_params);
		}

		return LORAWAN_NODE_STATUS_OK;
	}
}

uint8_t lorawan_node_get_payload_sizes(uint8_t *max_next_payload_size)
{
	LoRaMacTxInfo_t tx_info;

	assert(lorawan_node_config);
	/* QueryTxPossible cannot fail */
	LoRaMacQueryTxPossible(0, &tx_info);

	*max_next_payload_size = tx_info.MaxPossibleApplicationDataSize;
	return tx_info.CurrentPossiblePayloadSize;
}

enum lorawan_node_status lorawan_node_send(uint8_t port, const void *data, uint8_t size,
					   bool tx_confirmed)
{
	LoRaMacStatus_t status;
	McpsReq_t mcps_req;
	LoRaMacTxInfo_t tx_info;

	assert(lorawan_node_config);

	if (lorawan_node_is_joined() == false) {
		return LORAWAN_NODE_STATUS_NO_NETWORK_JOINED;
	}

	if (LoRaMacIsBusy()) {
		return LORAWAN_NODE_STATUS_BUSY;
	}

	if (k_uptime_get_32() < lorawan_node_runtime.duty_cycle_time) {
		return LORAWAN_NODE_STATUS_DUTYCYCLE_RESTRICTED;
	}
#ifdef CONFIG_LORAWAN_NODE_DEFAULT_DR
	mcps_req.Req.Unconfirmed.Datarate = CONFIG_LORAWAN_NODE_DEFAULT_DR;
#else
	mcps_req.Req.Unconfirmed.Datarate = LORAWAN_NODE_DR_0;
#endif
	if (LoRaMacQueryTxPossible(size, &tx_info) != LORAMAC_STATUS_OK) {
		/* Send empty frame in order to flush MAC commands */
		mcps_req.Type = MCPS_UNCONFIRMED;
		mcps_req.Req.Unconfirmed.fBuffer = NULL;
		mcps_req.Req.Unconfirmed.fBufferSize = 0;
		LoRaMacMcpsRequest(&mcps_req, false);
		lorawan_node_runtime.duty_cycle_time = k_uptime_get_32();
		lorawan_node_runtime.duty_cycle_time += mcps_req.ReqReturn.DutyCycleWaitTime;
		return LORAWAN_NODE_STATUS_SKIPPED_APP_DATA;
	} else {
		mcps_req.Req.Unconfirmed.fPort = port;
		mcps_req.Req.Unconfirmed.fBufferSize = size;
		mcps_req.Req.Unconfirmed.fBuffer = (void *)data;
		if (tx_confirmed == false) {
			mcps_req.Type = MCPS_UNCONFIRMED;
		} else {
			mcps_req.Type = MCPS_CONFIRMED;
		}
		status = LoRaMacMcpsRequest(&mcps_req, false);
		lorawan_node_runtime.duty_cycle_time = k_uptime_get_32();
		lorawan_node_runtime.duty_cycle_time += mcps_req.ReqReturn.DutyCycleWaitTime;
		return (enum lorawan_node_status)status;
	}
}

enum lorawan_node_status lorawan_node_switch_class(enum lorawan_node_class new_class)
{
	LoRaMacStatus_t status;
	MibRequestConfirm_t mib_req;
	enum lorawan_node_class current_class;

	assert(lorawan_node_config);

	if (lorawan_node_is_joined() == false) {
		return LORAWAN_NODE_STATUS_NO_NETWORK_JOINED;
	}

	mib_req.Type = MIB_DEVICE_CLASS;
	status = LoRaMacMibGetRequestConfirm(&mib_req);
	if (status != LORAMAC_STATUS_OK) {
		return (enum lorawan_node_status)status;
	}
	current_class = (enum lorawan_node_class)mib_req.Param.Class;

	/* Attempt to switch only if class update */
	if (current_class != new_class) {
		switch (new_class) {
		case LORAWAN_NODE_CLASS_A: {
			mib_req.Param.Class = CLASS_A;
			status = LoRaMacMibSetRequestConfirm(&mib_req);
			if (status != LORAMAC_STATUS_OK) {
				return (enum lorawan_node_status)status;
			} else {
				enum lorawan_node_status status;
				/* Tell the network server, class has been changed */
				status = lorawan_node_send(0, NULL, 0, false);
				if (status != LORAWAN_NODE_STATUS_OK) {
					return status;
				}
			}

			/* Switch is instantaneous */
			if (lorawan_node_config->callbacks.class_changed) {
				lorawan_node_config->callbacks.class_changed(LORAWAN_NODE_CLASS_A);
			}
			return LORAWAN_NODE_STATUS_OK;
		} break;
		case LORAWAN_NODE_CLASS_B: {
#if CONFIG_LORAWAN_NODE_CLASSB == 1
			if (current_class != LORAWAN_NODE_CLASS_A) {
				return LORAWAN_NODE_STATUS_PARAMETER_INVALID;
			} else {
				lorawan_node_runtime.classb_pending = true;
				/* Sync device time first */
				return lorawan_node_device_time_req();
			}
#else  /* CONFIG_LORAWAN_NODE_CLASSB == 0 */
			return LORAWAN_NODE_STATUS_PARAMETER_INVALID;
#endif /* CONFIG_LORAWAN_NODE_CLASSB */
		} break;
		case LORAWAN_NODE_CLASS_C: {
			if (current_class != LORAWAN_NODE_CLASS_A) {
				return LORAWAN_NODE_STATUS_PARAMETER_INVALID;
			}
			/* Switch is instantaneous */
			mib_req.Param.Class = CLASS_C;
			status = LoRaMacMibSetRequestConfirm(&mib_req);
			if (status != LORAMAC_STATUS_OK) {
				return (enum lorawan_node_status)status;
			} else {
				enum lorawan_node_status status;
				status = lorawan_node_send(0, NULL, 0, true);
				if (status != LORAWAN_NODE_STATUS_OK) {
					return status;
				}
			}
			if (lorawan_node_config->callbacks.class_changed) {
				lorawan_node_config->callbacks.class_changed(
					(enum lorawan_node_class)CLASS_C);
			}
			return LORAWAN_NODE_STATUS_OK;
		} break;
		default:
			return LORAWAN_NODE_STATUS_PARAMETER_INVALID;
		}
	}
	return LORAWAN_NODE_STATUS_PARAMETER_INVALID;
}

void lorawan_node_process(void)
{
	assert(lorawan_node_config);
	LoRaMacProcess();
	lorawan_node_nvm_ctx_store();
}

enum lorawan_node_status lorawan_node_device_time_req(void)
{
	LoRaMacStatus_t status;
	MlmeReq_t mlme_req;

	mlme_req.Type = MLME_DEVICE_TIME;
	status = LoRaMacMlmeRequest(&mlme_req);
	if (status == LORAMAC_STATUS_OK) {
		return lorawan_node_send(0, NULL, 0, false);
	} else {
		return (enum lorawan_node_status)status;
	}
}

enum lorawan_node_status lorawan_node_deinit(void)
{
	assert(lorawan_node_config);

	LoRaMacStatus_t status = LoRaMacDeInitialization();
	if (status == LORAMAC_STATUS_OK) {
		lorawan_node_config = NULL;
	}
	return (enum lorawan_node_status)status;
}

bool lorawan_node_is_busy(void)
{
	assert(lorawan_node_config);

	if (lorawan_node_is_joined() == false) {
		return true;
	}

	if (LoRaMacIsBusy()) {
		return true;
	}

	return false;
}

bool lorawan_node_is_joined()
{
	MibRequestConfirm_t mibReq;
	LoRaMacStatus_t status;

	assert(lorawan_node_config);

	mibReq.Type = MIB_NETWORK_ACTIVATION;
	status = LoRaMacMibGetRequestConfirm(&mibReq);
	assert(status == LORAMAC_STATUS_OK);
	if (mibReq.Param.NetworkActivation == ACTIVATION_TYPE_NONE) {
		return false;
	} else {
		return true;
	}
}

enum lorawan_node_class lorawan_node_get_current_class(void)
{
	LoRaMacStatus_t status;
	MibRequestConfirm_t mibReq;

	assert(lorawan_node_config);

	mibReq.Type = MIB_DEVICE_CLASS;
	status = LoRaMacMibGetRequestConfirm(&mibReq);
	assert(status == LORAMAC_STATUS_OK);

	return (enum lorawan_node_class)mibReq.Param.Class;
}

uint32_t lorawan_node_get_current_time(uint16_t *subseconds)
{
	SysTime_t systime = SysTimeGet();

	if (subseconds) {
		*subseconds = systime.SubSeconds;
	}
	return systime.Seconds;
}

bool lorawan_node_classb_pending(void)
{
	assert(lorawan_node_config);
	return lorawan_node_runtime.classb_pending;
}

bool lorawan_node_is_initialed(void)
{
	return lorawan_node_config != NULL;
}

uint32_t lorawan_node_get_duty_cycle_time(void)
{
	assert(lorawan_node_config);
	return lorawan_node_runtime.duty_cycle_time;
}

uint32_t lorawan_node_get_actived_region(void)
{
	assert(lorawan_node_config);
	return lorawan_node_runtime.actived_region;
}

uint8_t lorawan_node_get_tx_data_rate(void)
{
	LoRaMacStatus_t status;
	MibRequestConfirm_t mibGet;

	assert(lorawan_node_config);

	mibGet.Type = MIB_CHANNELS_DATARATE;
	status = LoRaMacMibGetRequestConfirm(&mibGet);
	assert(status == LORAMAC_STATUS_OK);

	return mibGet.Param.ChannelsDatarate;
}

bool lorawan_node_set_tx_data_rate(int8_t txDatarate)
{
	assert(lorawan_node_config);

#ifdef CONFIG_LORAWAN_NODE_ADR
	return false;
#endif

	LoRaMacStatus_t status;
	MibRequestConfirm_t mibReq;

	mibReq.Type = MIB_CHANNELS_DATARATE;
	mibReq.Param.ChannelsDatarate = txDatarate;
	status = LoRaMacMibSetRequestConfirm(&mibReq);
	assert(status == LORAMAC_STATUS_OK);

	return true;
}

const uint8_t *lorawan_node_get_dev_eui(void)
{
	assert(lorawan_node_config);
	return lorawan_node_runtime.device_eui;
}

const uint8_t *lorawan_node_get_app_eui(void)
{
	assert(lorawan_node_config);
	return lorawan_node_runtime.join_eui;
}

uint32_t lorawan_node_get_dev_addr(void)
{
	assert(lorawan_node_config);
	return lorawan_node_runtime.device_address;
}

bool lorawan_node_is_duty_cycle_enabled(void)
{
	assert(lorawan_node_config);
	return lorawan_node_runtime.duty_cycle_enabled;
}

void lorawan_node_enable_duty_cycle(bool dutyCycleEnable)
{
	assert(lorawan_node_config);

	LoRaMacTestSetDutyCycleOn(dutyCycleEnable);
	lorawan_node_runtime.duty_cycle_enabled = dutyCycleEnable;
}

uint8_t lorawan_node_get_tx_power(void)
{
	LoRaMacStatus_t status;
	MibRequestConfirm_t mibReq;

	assert(lorawan_node_config);

	mibReq.Type = MIB_CHANNELS_TX_POWER;
	status = LoRaMacMibGetRequestConfirm(&mibReq);
	assert(status == LORAMAC_STATUS_OK);

	return mibReq.Param.ChannelsTxPower;
}

void lorawan_node_set_tx_power(int8_t txPower)
{
	LoRaMacStatus_t status;
	MibRequestConfirm_t mibReq;

	assert(lorawan_node_config);

	mibReq.Type = MIB_CHANNELS_TX_POWER;
	mibReq.Param.ChannelsTxPower = txPower;
	status = LoRaMacMibSetRequestConfirm(&mibReq);

	assert(status == LORAMAC_STATUS_OK);
}

uint32_t lorawan_node_get_rx1_delay(void)
{
	LoRaMacStatus_t status;
	MibRequestConfirm_t mibReq;

	assert(lorawan_node_config);

	mibReq.Type = MIB_RECEIVE_DELAY_1;
	status = LoRaMacMibGetRequestConfirm(&mibReq);
	assert(status == LORAMAC_STATUS_OK);

	return mibReq.Param.ReceiveDelay1;
}

uint32_t lorawan_node_get_rx2_delay(void)
{
	LoRaMacStatus_t status;
	MibRequestConfirm_t mibReq;

	assert(lorawan_node_config);

	mibReq.Type = MIB_RECEIVE_DELAY_2;
	status = LoRaMacMibGetRequestConfirm(&mibReq);
	assert(status == LORAMAC_STATUS_OK);

	return mibReq.Param.ReceiveDelay2;
}

uint32_t lorawan_node_get_rx2_freq(void)
{
	LoRaMacStatus_t status;
	MibRequestConfirm_t mibReq;

	assert(lorawan_node_config);

	mibReq.Type = MIB_RX2_CHANNEL;
	status = LoRaMacMibGetRequestConfirm(&mibReq);
	assert(status == LORAMAC_STATUS_OK);

	return mibReq.Param.Rx2Channel.Frequency;
}

uint32_t lorawan_node_get_rx2_data_rate(void)
{
	LoRaMacStatus_t status;
	MibRequestConfirm_t mibReq;

	assert(lorawan_node_config);

	mibReq.Type = MIB_RX2_CHANNEL;
	status = LoRaMacMibGetRequestConfirm(&mibReq);
	assert(status == LORAMAC_STATUS_OK);

	return mibReq.Param.Rx2Channel.Datarate;
}

uint32_t lorawan_node_get_accept_rx1_delay(void)
{
	LoRaMacStatus_t status;
	MibRequestConfirm_t mibReq;

	assert(lorawan_node_config);

	mibReq.Type = MIB_JOIN_ACCEPT_DELAY_1;
	status = LoRaMacMibGetRequestConfirm(&mibReq);
	assert(status == LORAMAC_STATUS_OK);

	return mibReq.Param.JoinAcceptDelay1;
}

uint32_t lorawan_node_get_accept_rx2_delay(void)
{
	LoRaMacStatus_t status;
	MibRequestConfirm_t mibReq;

	assert(lorawan_node_config);

	mibReq.Type = MIB_JOIN_ACCEPT_DELAY_2;
	status = LoRaMacMibGetRequestConfirm(&mibReq);
	assert(status == LORAMAC_STATUS_OK);

	return mibReq.Param.JoinAcceptDelay2;
}
